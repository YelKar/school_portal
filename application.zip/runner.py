"""
importing application object and running site
"""
from application import application


if __name__ == '__main__':
    application.run(host="0.0.0.0")
